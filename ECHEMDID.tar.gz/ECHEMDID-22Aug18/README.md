# Version 
This code was tested with lammps-22Aug18 version.

# Files
- fix_echemdid.*
- fix_qeq.* // Slight modification to enable echemdid 
- fix_qeq_shielded.* // Slight modification to enable echemdid 

# Install
`make yes-qeq`  
`make yes-user-echemdid` // In this order

# Usage
See examples directory
